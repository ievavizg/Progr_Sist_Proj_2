public class SimpleTrip extends Trip{

}
