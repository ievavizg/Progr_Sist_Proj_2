public interface TripExtension {

    String getDescription();
    Double getFullCost();

}
